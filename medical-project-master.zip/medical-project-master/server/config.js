const config = {
  mongoUrl:
    'mongodb+srv://medical:medical123@cluster0-tcfrr.mongodb.net/medical_counselling?retryWrites=true&w=majority',
};
//// mongodb+srv://medical:medical123@cluster0-tcfrr.mongodb.net/medical?retryWrites=true&w=majority
module.exports = config;
