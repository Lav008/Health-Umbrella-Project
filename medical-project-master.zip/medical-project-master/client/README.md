Running on - medical-platform.surge.sh


## Installation Instructions
### Frontend
* Clone or download the repo. into any fresh temporary folder.
```
git clone https://github.com/Paarmita/MedicalProject
```
* Cd into that root folder you just cloned locally.
```
cd MedicalProject && cd Client
```
* Open terminal in the current folder and to install all dependencies type and 
```
npm install
```
* Now typing to start client 
``` 
 npm start
 ```
 * Window will automatically open at http://localhost:3000

 