

export const fakeData = [
	{
		21: {
			Name: 'Type1',
			Description: 'ABC',
			BestTherapy: 'BestTherapy',
			Disease: 'Diabities',
			Allopathy: {
				Efficiency: 'Allopathy Efficiency',
				Advantages: 'Allopathy Advantages',
				Disadvantages: 'Allopathy Disadvantages',
				Summary: 'Allopathy Summary',
				Ratings: 'Allopathy Ratings',
			},
			Homeopathy: {
				Efficiency: ' Homeopathy Efficiency',
				Advantages: ' Homeopathy Advantages',
				Disadvantages: 'Homeopathy Disadvantages',
				Summary: 'Homeopathy Summary',
				Ratings: 'Homeopathy Ratings',
			},
			Ayurveda: {
				Efficiency: 'Ayurveda Efficiency',
				Advantages: 'Ayurveda Advantages',
				Disadvantages: 'Ayurveda Disadvantages',
				Summary: 'Ayurveda Summary',
				Ratings: 'Ayurveda Ratings',
			},
		},
		22: {
			Name: 'Type2',
			Description: 'XYZ',
			BestTherapy: 'BestTherapy',
			Allopathy: {
				Efficiency: 'Allopathy Efficiency',
				Advantages: 'Allopathy Advantages',
				Disadvantages: 'Allopathy Disadvantages',
				Summary: 'Allopathy Summary',
				Ratings: 'Allopathy Ratings',
			},
			Homeopathy: {
				Efficiency: ' Homeopathy Efficiency',
				Advantages: ' Homeopathy Advantages',
				Disadvantages: 'Homeopathy Disadvantages',
				Summary: 'Homeopathy Summary',
				Ratings: 'Homeopathy Ratings',
			},
			Ayurveda: {
				Efficiency: 'Ayurveda Efficiency',
				Advantages: 'Ayurveda Advantages',
				Disadvantages: 'Ayurveda Disadvantages',
				Summary: 'Ayurveda Summary',
				Ratings: 'Ayurveda Ratings',
			},
		},
	},
];
export default fakeData;
