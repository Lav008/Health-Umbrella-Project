export const serverUrl = 'https://infinite-harbor-95705.herokuapp.com';
// export const serverUrl = 'http://localhost:5000';
//export const clientUrl = 'http://localhost:3000';
// export const serverUrl = '${serverUrl}';
export const clientUrl = 'https://gifted-gates-e3aa20.netlify.app';

export const admins = ['Abhishek7soni@gmail.com'];
